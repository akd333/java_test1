package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dto.FlatOwnersDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RealEstateException;

public interface IFlatRegistrationService {
	
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws RealEstateException;
	public List<FlatOwnersDTO> getAllOwnerId() throws RealEstateException;
	public boolean isValidFlatRegistration(FlatRegistrationDTO flat) throws RealEstateException; 
}
