package com.cg.frs.service;

import java.util.List;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatOwnersDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RealEstateException;



public class FlatRegistrationServiceImpl implements IFlatRegistrationService{
	IFlatRegistrationDAO dao = new FlatRegistrationDAOImpl();
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws RealEstateException {

		return dao.registerFlat(flat);
	}

	@Override
	public boolean isValidFlatRegistration(FlatRegistrationDTO flat)
			throws RealEstateException {

		return true;
	}

	@Override
	public List<FlatOwnersDTO> getAllOwnerId() throws RealEstateException {

		return dao.getAllOwnerId();
	}
}