package com.cg.frs.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.frs.dto.FlatOwnersDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RealEstateException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Client {

	public static void main(String[] args) throws RealEstateException {

		IFlatRegistrationService fs = new FlatRegistrationServiceImpl();
		Scanner scanner = new Scanner(System.in);

		do {
			System.out.println("1. Register Flat");
			System.out.println("2. Exit");
			String choice = scanner.nextLine();
			switch (choice) {
			case "1":
				try{
					List<FlatOwnersDTO> flist = fs.getAllOwnerId();
					if(flist.size()==0)

						System.out.println("No Owners Available");
					else{
						System.out.println("Existing owners Id's are :");
						for(FlatOwnersDTO f1:flist)

							System.out.println(f1);
					}
					System.out.println("Select Owner Id from above list");
					String ownerId = scanner.nextLine();
					System.out.println("Select Flat Type(1-1BHK, 2-2BHK)");
					String flatType = scanner.nextLine();
					System.out.println("Enter flat area in square feet:");
					String flatArea = scanner.nextLine();
					System.out.println("Enter Desired Rent Amount");
					String rentAmount = scanner.nextLine();
					System.out.println("Enter Desired Deposit Amount");
					String depositAmount = scanner.nextLine();
					FlatRegistrationDTO fr = new FlatRegistrationDTO(null,ownerId,flatType,flatArea,rentAmount,depositAmount);

					try {

						if(fs.isValidFlatRegistration(fr))
							fs.registerFlat(fr);

						System.out.println("Flat Succesfully Registered :" + fr.getFlatRegNo());

					}
					catch (RealEstateException e) {
						System.err.println(e.getMessage());
					}
				} catch (RealEstateException e1) {

					System.err.println(e1.getMessage());
				}
				break;
			case "2":
				System.exit(0);
				break;
			default:
				System.err.println("Enter Valid Choice");
				break;
			}
		} while (true);

	}

}
