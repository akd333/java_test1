package com.cg.frs.dao;

import java.util.List;

import com.cg.frs.dto.FlatOwnersDTO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RealEstateException;

public interface IFlatRegistrationDAO {
	public List<FlatOwnersDTO> getAllOwnerId() throws RealEstateException;;
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) throws RealEstateException;
}
