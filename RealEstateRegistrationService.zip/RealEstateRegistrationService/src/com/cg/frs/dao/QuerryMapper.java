package com.cg.frs.dao;

public interface QuerryMapper {
	public static final String RETRIVE_ALL_OWNERID_QUERY="SELECT owner_id FROM flat_owners";
	public static final String INSERT_REGISTRATION_QUERY="INSERT INTO flat_registration VALUES(?,?,?,?,?,?)";
	public static final String REGISTRATIONID_SEQUENCE_QUERY="SELECT flat_seq.NEXTVAL FROM dual";
}
